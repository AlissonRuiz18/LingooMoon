function verificarRespuestas() {
    var total = 25;
    var puntos = 0;

    var myForm = document.forms["quiz"];
    var respuestas = ["c", "a", "a", "c", "a", "a", "a", "a", "c", "b", "c", "b", "a", "b", "b", "b", "a", "c", "c", "a", "a", "a", "b", "c", "b"];

    for (var i = 1; i <= total; i++) {
        if (myForm["q + i"].value === null || myForm["q" + i].value === "") {
            alert("Por favor responde a la pregunta" + i);
            return false;
        }
        else {
            if (myForm["q" + i].value === respuestas[i - 1]) {
                ++puntos;
            }
        }
    }
    var resultado = document.getElementById("resultado");
    resultado.innerHTML = '<p>Obtuvistes <span>' + puntos + '</span> de <span>' + total + 'punto</span></p>';



    return false;
};



