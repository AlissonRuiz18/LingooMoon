Swal.fire({
    title: "Bienvenido a LingooMoon!",
    text: "Espero que te guste nuestra pagina web!",
    backdrop: true,
    allowOutsideClick: false,
    confirmButtonText: 'Espero!'
})
