LingooMoon
Video Demo: https://youtu.be/zQ7J1MheQic
 Description: 
 LingooMoon es una aplicacion web construida por dos estudiantes :

- Alisson Melisa Ruiz Barahona
- Hector Danilo Fuentes Aguirre.
 Lenguajes/Recursos utilizados:
- Python
- Framework Flask
- Boostrap
- HTML , CSS , Javascript
- PostgreSQL


Dispone de un resgistro para que los estudiantes puedan registrarse y llevar un seguimiento de su desarrollo.

LingooMoon , es un blog dirigido a estudiantes del idioma ingles ,especialmente a personas que estan  en busca de informacion concreta de lo que son Phrasal verbs , Idioms y Social expressions , que son temas importantes pero que a la vez se les dificulta a los estudiantes , es por ello que decidimos crear este espacio como estudiantes pensando en nuestros problemas comunes en ingles asi como para aquellos estudiantes de pocos recursos que desean superarse en el idioma ingles. Como tambien , creamos un espacio para que los estudiantes puedan explorar otros recursos importantes para mejorar sus habilidades del idioma ingles de una forma autodidacta y dinamica.
Como funciona LingooMoon Dentro de LingooMoon en su pagina principal podemos observar que contiene un menu lateral en donde podemos encontrar las palabras EasyPlanet , MediumPlanet y HardPlanet , estas secciones se refieren a los niveles de dificultad de los temas ya mencionados , dentro de estas secciones por ejemplo en Easy planet Se desglosa lo que es:

-15 Phrasal verbs
-15Idioms
-15 Social expression y al final encontramos un quiz en donde el estudiante pondra a prueba todo lo que aprendio en las secciones anteriores.Es asi como LingooMoon funciona , en donde va incrementando la dificultad mientras mas vocabulario el estudiante tenga que aprender para que lo ponga a prueba en los quizzes de cada nivel.
Como parte de la pagina tambien tenemos dos secciones en donde el estudiante puede explorar nuevos recursos como por ejemplo : Paginas web , Aplicaciones moviles , Canales de youtube entre otros.Seguido de esto , tambien creamos recomendaciones dirigidas a personas autodidactas o para personas que quieran nutrirce de mas conocimiento para perfeccionar su ingles.

Los objetivos de nuestro proyecto son los siguientes:
 - Ayudar a las personas a comprender los phrasal verbs , idioms y social expressions
  - Agrandar el conocimiento de las personas que quieran aprender estos temas 
- Mejorar el vocabulario para que los estudiantes puedan tener buenas habilidades comunicativas en Ingles.

