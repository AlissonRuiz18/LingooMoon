<?php

$host='localhost';
$bd='empresa';
$user='postgres';
$pass='1234';

$conexion=pg_connect("host=$host dbname=$bd user=$user password=$pass");








?>